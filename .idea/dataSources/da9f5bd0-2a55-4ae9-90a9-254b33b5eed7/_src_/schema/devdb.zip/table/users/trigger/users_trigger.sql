CREATE TRIGGER users_trigger
BEFORE INSERT ON users
FOR EACH ROW
  BEGIN
    DECLARE usernameLength INT;
    DECLARE passwordLength INT;
    SET usernameLength = (SELECT LENGTH(NEW.userName));
    IF (usernameLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Username must consist of 3 characters at least!!!';
    END IF;
    SET passwordLength = (SELECT LENGTH(NEW.password));
    IF (passwordLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Password must consist of 3 characters at least!!!';
    END IF;
  END;
