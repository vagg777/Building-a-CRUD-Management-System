CREATE TRIGGER department_trigger
BEFORE INSERT ON department
FOR EACH ROW
  BEGIN
    DECLARE departmentNameLength INT;
    DECLARE departmentStreetLength INT;
    SET departmentNameLength = (SELECT LENGTH(NEW.name));
    IF (departmentNameLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Department Name must consist of 3 characters at least!!!';
    END IF;
    SET departmentStreetLength = (SELECT LENGTH(NEW.street));
    IF (departmentStreetLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Department Street must consist of 3 characters at least!!!';
    END IF;
  END;
