CREATE TRIGGER employee_trigger
BEFORE INSERT ON employee
FOR EACH ROW
  BEGIN
    DECLARE employeeFirstNameLength INT;
    DECLARE employeeLastNameLength INT;
    DECLARE employeeBirthYearLength INT;
    SET employeeFirstNameLength = (SELECT LENGTH(NEW.first_name));
    IF (employeeFirstNameLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: First Name must consist of 3 characters at least!!!';
    END IF;
    SET employeeLastNameLength = (SELECT LENGTH(NEW.last_name));
    IF (employeeLastNameLength) < 3 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Last Name must consist of 3 characters at least!!!';
    END IF;
    SET employeeBirthYearLength = (SELECT LENGTH(NEW.born));
    IF (employeeBirthYearLength) != 4 THEN
      SIGNAL SQLSTATE '45000' set message_text='Error: Birth Year must consist of 4 characters!!!';
    END IF;
  END;
